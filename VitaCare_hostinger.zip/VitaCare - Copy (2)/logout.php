<?php
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'logout') {
    $_SESSION = array();
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    
    session_destroy();
    
    echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
    exit();
}

echo json_encode(['success' => false, 'message' => 'Invalid request']);
exit();
?>