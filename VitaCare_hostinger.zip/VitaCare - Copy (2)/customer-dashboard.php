<?php
session_start();


$profilePage = "profilepage.php";
$addVitaminPage = "add-vitamin_customer.php";

// Make sure user name is properly stored in session
if (!isset($_SESSION['user_name']) && isset($_SESSION['user_id'])) {
    // Try to fetch from database if needed
    include 'db_connection.php';
    try {
        $stmt = $pdo->prepare("SELECT UserName FROM user WHERE UserId = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            $_SESSION['user_name'] = $user['UserName'];
        }
    } catch (PDOException $e) {
        // Fallback
        $_SESSION['user_name'] = $_SESSION['name'] ?? "User";
    }
}

$userName = $_SESSION['user_name'] ?? $_SESSION['name'] ?? "User";

if (!isset($_SESSION['userVitamins'])) {
    $_SESSION['userVitamins'] = [];
}

if (!isset($_SESSION['takenVitamins'])) {
    $_SESSION['takenVitamins'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    $action = $_POST['action'];

    if ($action === 'edit') {
        $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;
        $name = trim($_POST['name'] ?? '');
        $time = trim($_POST['time'] ?? '');
        $numberOfPills = trim($_POST['numberOfPills'] ?? '');

        if (!isset($_SESSION['userVitamins'][$index])) {
            echo json_encode(['success' => false, 'message' => 'Vitamin not found.']);
            exit();
        }

        if ($name === '' || $time === '' || $numberOfPills === '' || !is_numeric($numberOfPills) || (int)$numberOfPills <= 0) {
            echo json_encode(['success' => false, 'message' => 'Please enter valid vitamin information.']);
            exit();
        }

        if (!preg_match('/[A-Za-z]/', $name)) {
            echo json_encode(['success' => false, 'message' => 'Vitamin name cannot be numbers only.']);
            exit();
        }

        $_SESSION['userVitamins'][$index]['name'] = $name;
        $_SESSION['userVitamins'][$index]['time'] = $time;
        $_SESSION['userVitamins'][$index]['numberOfPills'] = (int)$numberOfPills;

        echo json_encode([
            'success' => true,
            'vitamins' => array_values($_SESSION['userVitamins']),
            'taken' => array_values($_SESSION['takenVitamins'])
        ]);
        exit();
    }

    if ($action === 'delete') {
        $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;

        if (!isset($_SESSION['userVitamins'][$index])) {
            echo json_encode(['success' => false, 'message' => 'Vitamin not found.']);
            exit();
        }

        array_splice($_SESSION['userVitamins'], $index, 1);

        $updatedTaken = [];

        foreach ($_SESSION['takenVitamins'] as $takenItem) {
            if (!str_contains($takenItem, '_')) {
                continue;
            }

            [$takenIndex, $takenDay] = explode('_', $takenItem, 2);
            $takenIndex = (int)$takenIndex;

            if ($takenIndex === $index) {
                continue;
            }

            if ($takenIndex > $index) {
                $takenIndex = $takenIndex - 1;
            }

            $updatedTaken[] = $takenIndex . '_' . $takenDay;
        }

        $_SESSION['takenVitamins'] = $updatedTaken;

        echo json_encode([
            'success' => true,
            'vitamins' => array_values($_SESSION['userVitamins']),
            'taken' => array_values($_SESSION['takenVitamins'])
        ]);
        exit();
    }

    if ($action === 'toggleTaken') {
        $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;
        $day = trim($_POST['day'] ?? '');

        if (!isset($_SESSION['userVitamins'][$index])) {
            echo json_encode(['success' => false, 'message' => 'Vitamin not found.']);
            exit();
        }

        if ($day === '') {
            echo json_encode(['success' => false, 'message' => 'Day is required.']);
            exit();
        }

        $takenKey = $index . '_' . $day;

        if (in_array($takenKey, $_SESSION['takenVitamins'])) {
            $_SESSION['takenVitamins'] = array_values(array_filter(
                $_SESSION['takenVitamins'],
                fn($item) => $item !== $takenKey
            ));
        } else {
            $_SESSION['takenVitamins'][] = $takenKey;
        }

        echo json_encode([
            'success' => true,
            'vitamins' => array_values($_SESSION['userVitamins']),
            'taken' => array_values($_SESSION['takenVitamins'])
        ]);
        exit();
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    exit();
}

$userVitamins = array_values($_SESSION['userVitamins']);
$takenVitamins = array_values($_SESSION['takenVitamins']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VitaCare - My Vitamins</title>

<link rel="stylesheet" href="customer-dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>

<div class="navbar">
    <div class="logo">
        <img src="image/logo.PNG" alt="VitaCare Logo">
    </div>

    <div class="nav-title">
        My Vitamins
    </div>

    <a href="<?php echo htmlspecialchars($profilePage); ?>" class="user-menu">
        <img src="image/icon.png" alt="User" class="user-img">
        <span><?php echo htmlspecialchars($userName); ?></span>
    </a>
</div>

<div class="container">
    <div class="main-card">
        <div class="page-header">
            <div class="title-box">
                <h1>My Vitamins</h1>
                <p>View and manage your vitamins</p>
            </div>
            <a href="<?php echo htmlspecialchars($addVitaminPage); ?>" class="add-btn">
                <i class="fa-solid fa-plus"></i> Add Vitamin
            </a>
        </div>
        <div id="messageBox" class="message-box"></div>
        <div class="table-wrapper" id="tableWrapper">
            <table class="vitamin-table">
                <thead>
                    <tr>
                        <th>Sunday</th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                        <th>Saturday</th>
                    </tr>
                </thead>
                <tbody>
                    <tr id="tableRow"></tr>
                </tbody>
            </table>
        </div>

        <div class="streak-box">
            <div class="streak-title">Current Streak</div>
            <div class="streak-number" id="streakNumber">0</div>
            <div class="streak-note">Based on completed daily vitamin intake</div>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="footer-inner">
        <div class="footer-left">
            <strong>Contact Us:</strong>
        </div>
        <div class="footer-mid">
            <span class="contact-item">
                <img class="icon" src="image/email.png" alt="Email">
                <a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
            </span>
            <span class="contact-item">
                <img class="icon" src="image/phone.png" alt="Phone">
                <a class="footer-link" href="tel:+966556678127">+966 556678127</a>
            </span>
        </div>
        <div class="footer-bottom">
            &copy; 2026 VitaCare
        </div>
    </div>
</footer>

<div class="custom-modal" id="editModal">
    <div class="custom-modal-content">
        <h2>Edit Vitamin</h2>
        <div id="modalMessage" class="message-box"></div>
        <input type="hidden" id="editIndex">
        <label for="editName">Vitamin Name</label>
        <input type="text" id="editName">
        <label for="editTime">Time</label>
        <input type="time" id="editTime">
        <label for="editPills">Number of Pills</label>
        <input type="number" id="editPills" min="1">
        <div class="modal-actions">
            <button type="button" class="save-btn" onclick="saveEdit()">Save</button>
            <button type="button" class="cancel-btn" onclick="closeEditModal()">Cancel</button>
        </div>
    </div>
</div>

<div class="custom-modal" id="deleteModal">
    <div class="custom-modal-content">
        <h2>Delete Vitamin</h2>
        <p>Are you sure you want to delete this vitamin?</p>
        <input type="hidden" id="deleteIndex">
        <div class="modal-actions">
            <button type="button" class="delete-btn" onclick="confirmDelete()">Delete</button>
            <button type="button" class="cancel-btn" onclick="closeDeleteModal()">Cancel</button>
        </div>
    </div>
</div>

<script>
const INITIAL_VITAMINS = <?php echo json_encode($userVitamins, JSON_UNESCAPED_UNICODE); ?>;
const INITIAL_TAKEN = <?php echo json_encode($takenVitamins, JSON_UNESCAPED_UNICODE); ?>;
</script>
<script src="customer-dashboard.js?v=3"></script>

</body>
</html>