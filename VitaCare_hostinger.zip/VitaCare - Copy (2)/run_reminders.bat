@echo off
curl "http://localhost:8888/VitaCare/send_reminders.php"