<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userVitamins = isset($_SESSION['userVitamins']) ? array_values($_SESSION['userVitamins']) : [];
$takenVitamins = isset($_SESSION['takenVitamins']) ? array_values($_SESSION['takenVitamins']) : [];

try {
    $stmt = $pdo->prepare("SELECT UserName, Email FROM user WHERE UserId = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if ($user) {
        $_SESSION['user_name'] = $user['UserName'];
        $_SESSION['user_email'] = $user['Email'];
    }
} catch (PDOException $e) {
    $user = null;
}

$userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : ($user['UserName'] ?? 'User');
$userEmail = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ($user['Email'] ?? 'Not available');


$intakeHistory = [];

foreach ($userVitamins as $index => $vitamin) {
   
    $days = isset($vitamin['days']) ? $vitamin['days'] : [];
    
    
    if (!empty($days)) {
        foreach ($days as $day) {
            $takenKey = $index . '_' . $day;
            $status = in_array($takenKey, $takenVitamins) ? 'Taken' : 'Not Taken';
            $intakeHistory[] = [
                'vitamin_name' => $vitamin['name'],
                'day' => $day,
                'status' => $status,
                'time' => $vitamin['time'] ?? '--:--',
                'numberOfPills' => $vitamin['numberOfPills'] ?? '0'
            ];
        }
    } else {
      
        $intakeHistory[] = [
            'vitamin_name' => $vitamin['name'],
            'day' => 'No days specified',
            'status' => 'N/A',
            'time' => $vitamin['time'] ?? '--:--',
            'numberOfPills' => $vitamin['numberOfPills'] ?? '0'
        ];
    }
}

usort($intakeHistory, function($a, $b) {
    return strcmp($a['vitamin_name'], $b['vitamin_name']);
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VitaCare - My Profile</title>
<link rel="stylesheet" href="customer-dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
button {
    font-family: Georgia, "Times New Roman", serif;
}
.breadcrumbs { 
    margin: 20px 0; 
    font-family: Georgia, serif; 
    font-size: 15px; 
    color: #666; 
}
.breadcrumbs a { 
    color: #1f5fa8; 
    text-decoration: none; 
    font-weight: 500; 
}
.breadcrumbs a:hover { 
    text-decoration: underline; 
}
.breadcrumbs span { 
    color: #999; 
    margin: 0 5px; 
}
.profile-grid { 
    display: grid; 
    grid-template-columns: 1fr 2fr; 
    gap: 40px; 
    margin-top: 20px; 
}
.user-info-box { 
    text-align: center; 
    padding: 30px; 
    border-right: 1px solid #eee; 
    background: #fafafa; 
    border-radius: 15px; 
}
.avatar-container { 
    width: 130px; 
    height: 130px; 
    margin: 0 auto 20px; 
    border-radius: 50%; 
    border: 5px solid #fff; 
    box-shadow: 0 4px 10px rgba(0,0,0,0.1); 
    overflow: hidden; 
    display: flex; 
    justify-content: center; 
    align-items: center; 
    background: #fff; 
}
.avatar-container img { 
    width: 100%; 
    height: 100%; 
    object-fit: cover; 
}
.info-item { 
    margin-bottom: 20px; 
    font-size: 16px; 
}
.info-item strong { 
    display: block; 
    color: #1f5fa8; 
    font-size: 13px; 
    text-transform: uppercase; 
    letter-spacing: 1px; 
    margin-bottom: 5px; 
}
.status-tag { 
    padding: 5px 12px; 
    border-radius: 20px; 
    font-size: 12px; 
    font-weight: bold; 
    border: 1px solid; 
    display: inline-block; 
    min-width: 95px; 
    text-align: center; 
}
.status-taken { 
    background: #e8f5e9; 
    color: #2e7d32; 
    border-color: #c8e6c9; 
}
.status-not-taken { 
    background: #ffebee; 
    color: #c62828; 
    border-color: #ffcdd2; 
}
@media (max-width: 768px) { 
    .profile-grid { 
        grid-template-columns: 1fr; 
    } 
    .user-info-box { 
        border-right: none; 
        border-bottom: 1px solid #eee; 
    } 
}

.custom-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.35);
    z-index: 9999;
    justify-content: center;
    align-items: center;
}
.custom-modal.show {
    display: flex;
}
.custom-modal-content {
    background: #ffffff;
    width: 90%;
    max-width: 420px;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
.custom-modal-content h2 {
    margin-top: 0;
    margin-bottom: 18px;
    font-size: 24px;
    font-family: Georgia, "Times New Roman", serif;
    color: #333;
}
.custom-modal-content p {
    margin-bottom: 20px;
    font-size: 16px;
    font-family: Georgia, "Times New Roman", serif;
    color: #555;
}
.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}
.confirm-logout-btn {
    background: #f8e0e0;
    color: #c62828;
    border: none;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
    font-family: Georgia, "Times New Roman", serif;
}
.confirm-logout-btn:hover {
    background: #f8c6c6;
}
.cancel-btn {
    background: #eeeeee;
    border: none;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
    font-family: Georgia, "Times New Roman", serif;
}
.cancel-btn:hover {
    background: #dddddd;
}
.message-box {
    display: none;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 8px;
    font-size: 14px;
}
.message-error {
    background: #f8e0e0;
    color: #7a2d2d;
}
.message-success {
    background: #dff4df;
    color: #246024;
}
</style>
</head>
<body>

<div class="navbar">
    <div class="logo"><img src="image/logo.png" alt="VitaCare Logo"></div>
    <div class="nav-title">My Profile</div>
</div>

<div class="container">
    <nav class="breadcrumbs">
        <a href="customer-dashboard.php">My Vitamins</a> <span>/</span> My Profile
    </nav>

    <div class="main-card">
        <div class="page-header">
            <div class="title-box">
                <h1>Account Overview</h1>
                <p>Track your personal details and intake consistency</p>
            </div>
        </div>

        <div class="profile-grid">
            <aside class="user-info-box">
                <div class="avatar-container"><img src="image/icon.png" alt="Profile"></div>
                <div class="info-item">
                    <strong>Username</strong>
                    <?php echo htmlspecialchars($userName); ?>
                </div>
                <div class="info-item">
                    <strong>Email Address</strong>
                    <?php echo htmlspecialchars($userEmail); ?>
                </div>
                <div style="margin-top: 40px;">
                    <button id="logoutBtn" class="add-btn"
                            style="border: none; cursor: pointer; background-color: #f8e0e0; width: 100%; color: #c62828; font-family: Georgia, 'Times New Roman', serif;"
                            onmouseover="this.style.backgroundColor='#f8c6c6'" 
                            onmouseout="this.style.backgroundColor='#f8e0e0'">
                            <i class="fa-solid fa-sign-out-alt"></i> Log Out
                    </button>
                    <div id="messageBox" class="message-box" style="margin-top: 15px;"></div>
                </div>
            </aside>

            <section>
                <h2 style="margin-bottom: 20px; font-family: Georgia, serif; color: #333;">My Scheduled Vitamins</h2>
                <div class="table-wrapper">
                    <table class="vitamin-table">
                        <thead>
                            <tr><th>Vitamin</th><th>Time</th><th>Dose</th></tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($userVitamins)): ?>
                                <?php foreach ($userVitamins as $v): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($v['name'] ?? 'Unknown'); ?></td>
                                    <td><?php echo htmlspecialchars($v['time'] ?? '--:--'); ?></td>
                                    <td><?php echo htmlspecialchars($v['numberOfPills'] ?? '0'); ?> Pill(s)</td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" style="color: #888; padding: 20px; text-align: center;">No vitamins scheduled yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <h2 style="margin-top: 50px; margin-bottom: 20px; font-family: Georgia, serif; color: #333;">Intake History</h2>
                <div class="table-wrapper">
                    <table class="vitamin-table">
                        <thead>
                            <tr><th>Vitamin</th><th>Day</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($intakeHistory)): ?>
                                <?php foreach ($intakeHistory as $entry): 
                                    if ($entry['status'] == 'N/A') {
                                        $statusClass = 'status-not-taken';
                                        $statusIcon = '⚠';
                                    } else {
                                        $statusClass = ($entry['status'] == 'Taken') ? 'status-taken' : 'status-not-taken';
                                        $statusIcon = ($entry['status'] == 'Taken') ? '✓' : '✗';
                                    }
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($entry['vitamin_name']); ?></td>
                                    <td><?php echo htmlspecialchars($entry['day']); ?></td>
                                    <td><span class="status-tag <?php echo $statusClass; ?>"><?php echo $statusIcon . ' ' . $entry['status']; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" style="color: #888; padding: 20px; text-align: center;">No vitamins scheduled yet.<?php echo '<!-- Debug: ' . htmlspecialchars(json_encode($userVitamins)) . ' -->'; ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="footer-inner">
        <div class="footer-left"><strong>Contact Us:</strong></div>
        <div class="footer-mid">
            <span class="contact-item">
                <img class="icon" src="image/email.png" alt="Email">
                <a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
            </span>
            <span class="contact-item">
                <img class="icon" src="image/phone.png" alt="Phone">
                <a class="footer-link" href="tel:+966556678127">+966 556678127</a>
            </span>
        </div>
        <div class="footer-bottom">&copy; 2026 VitaCare. All rights reserved.</div>
    </div>
</footer>

<div id="logoutModal" class="custom-modal">
    <div class="custom-modal-content">
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out of your account?</p>
        <div class="modal-actions">
            <button type="button" id="confirmLogoutBtn" class="confirm-logout-btn" style="width:50%">Log Out</button>
            <button type="button" id="cancelLogoutModalBtn" class="cancel-btn" style="width:50%">Cancel</button>
        </div>
    </div>
</div>

<script src="profilepage.js"></script>
</body>
</html>