<?php
date_default_timezone_set('Asia/Riyadh');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'vitacare.notifications@gmail.com';
    $mail->Password   = 'kajwchukapwhveiu';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->CharSet = 'UTF-8';
    $mail->setFrom('vitacare.notifications@gmail.com', 'VitaCare');
    $mail->addAddress('YOUR_RECEIVER_EMAIL@gmail.com');

    $mail->isHTML(true);
    $mail->Subject = 'Test Email from VitaCare';
    $mail->Body    = '<h3>نجح اختبار الإيميل ✅</h3><p>إذا وصلتك هذه الرسالة فالإعدادات سليمة.</p>';

    $mail->send();
    echo "MAIL_SENT_OK";
} catch (Exception $e) {
    echo "MAIL_ERROR: " . $mail->ErrorInfo;
}