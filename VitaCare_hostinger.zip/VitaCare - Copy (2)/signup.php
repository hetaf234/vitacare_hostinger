<?php
// 1. Include the database connection
require_once 'db_connection.php'; 
session_start(); 

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 2. Capture and sanitize inputs
    $user = trim($_POST['userName']);
    $email = trim($_POST['email']);
    $raw_password = $_POST['password'];
    
    // 3. Hash the password (using BCRYPT)
    $hashed_password = password_hash($raw_password, PASSWORD_DEFAULT);
    $userType = 'customer'; 

    try {
        // 4. Check if the Email already exists
        $checkEmail = $pdo->prepare("SELECT Email FROM user WHERE Email = ?");
        $checkEmail->execute([$email]);
        
        if ($checkEmail->rowCount() > 0) {
            $message = "This email is already registered.";
        } else {
            // 5. Insert new user
            $sql = "INSERT INTO user (UserName, Email, Password, UserType) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$user, $email, $hashed_password, $userType]);
            
            // 6. Get the new user ID
            $userId = $pdo->lastInsertId();
            
            // 7. IMPORTANT: Create session for the new user
            $_SESSION['user_id'] = $userId;
            $_SESSION['user_name'] = $user;
            $_SESSION['user_email'] = $email;
            $_SESSION['userVitamins'] = [];
            $_SESSION['takenVitamins'] = [];
            
            // 8. Redirect to customer dashboard
            header("Location: customer-dashboard.php");
            exit();
        }
    } catch(PDOException $e) {
        $message = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>VitaCare - Sign Up</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .message-box {
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 8px;
      font-size: 14px;
      display: none;
    }
    .message-error {
      background: #f8e0e0;
      color: #c62828;
      border: 1px solid #ffcdd2;
    }
    .message-success {
      background: #dff4df;
      color: #2e7d32;
      border: 1px solid #c8e6c9;
    }
  </style>
</head>
<body>

  <main class="main">
    <section class="card">
      <h1>VitaCare</h1>

      <div class="logo">
        <img src="image/logo.png" alt="VitaCare logo">
      </div>

      <div id="modalMessage" class="message-box"></div>

      <form class="auth-form" action="signup.php" method="POST">
        <fieldset>
          <legend>Sign Up</legend>

          <label for="userName">User Name:</label>
          <input id="userName" name="userName" type="text" placeholder="Type your userName" required>

          <label for="email">Email Address:</label>
          <input id="email" name="email" type="email" placeholder="Type your email" required>

          <label for="password">Password:</label>
          <input id="password" name="password" type="password" placeholder="Type your password" required>
          <p id="pw-error" style="color: #d93025; font-size: 0.85rem; margin-top: 5px; display: none;"></p>

          <button class="btn btn-wide" type="submit">Create Account</button>

          <button
            class="btn btn-wide"
            type="button"
            onclick="window.location.href='index.php'">
            Back
          </button>

        </fieldset>
      </form>

    </section>
  </main>

  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-left">
        <strong>Contact Us:</strong>
      </div>

      <div class="footer-mid">
        <span class="contact-item">
          <img class="icon" src="image/email.png" alt="Email icon">
          <a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
        </span>

        <span class="contact-item">
          <img class="icon" src="image/phone.png" alt="Phone icon">
          <a class="footer-link" href="tel:+966556678127">+966 556678127</a>
        </span>
      </div>

      <div class="footer-bottom">
        &copy; 2026 <a class="footer-link" href="index.html">VitaCare</a>. All rights reserved.
      </div>
    </div>
  </footer>

  <script>
  const loginForm = document.querySelector(".auth-form");
  const passwordInput = document.getElementById("password");

  function showModalMessage(text, type = "error") {
    const box = document.getElementById("modalMessage");
    if (!box) return;
    
    box.innerText = text;
    box.className = "message-box message-" + type;
    box.style.display = "block";
    
    // Auto hide after 3 seconds
    setTimeout(function() {
      box.style.display = "none";
    }, 3000);
  }
  
  <?php if ($message): ?>
    showModalMessage("<?php echo addslashes($message); ?>", "error");
  <?php endif; ?>
  
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/;
      
      if (!passwordRegex.test(passwordInput.value)) {
        e.preventDefault(); 
        
        showModalMessage("Password must include uppercase, lowercase, a number, and a special character.", "error");
        
        passwordInput.focus();
      }
    });
  }
  </script>
</body>
</html>