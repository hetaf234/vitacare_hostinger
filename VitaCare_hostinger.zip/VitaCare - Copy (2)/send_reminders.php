<?php
date_default_timezone_set('Asia/Riyadh');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/db_connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

$mailConfig = require __DIR__ . '/mail_config.php';

$logFile = __DIR__ . '/task_log.txt';

function writeLog($message)
{
    global $logFile;
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, FILE_APPEND);
}

writeLog("Service Started");

try {
    $todayDate = date('Y-m-d');
    $todayDay  = date('l');

    $sql = "
        SELECT 
            cv.ScheduleId,
            cv.UserId,
            cv.NumOfPills,
            cv.IntakeTime,
            cv.FrequencyType,
            cv.StartDate,
            cv.EndDate,
            u.UserName,
            u.Email,
            vc.VitaminName,
            vc.VitaminDosage,
            vc.VitaminId
        FROM customervitamin cv
        INNER JOIN `user` u ON cv.UserId = u.UserId
        INNER JOIN vitamincatalog vc ON cv.VitaminId = vc.VitaminId
        WHERE
            -- 👇 تم التعديل هنا
            cv.IntakeTime BETWEEN (CURRENT_TIME() - INTERVAL 5 MINUTE) AND CURRENT_TIME()
            AND cv.StartDate <= :todayDate
            AND (cv.EndDate IS NULL OR cv.EndDate >= :todayDate)
            AND cv.FrequencyType LIKE :todayDay
            AND NOT EXISTS (
                SELECT 1
                FROM emailreminderlog erl
                WHERE erl.ScheduleId = cv.ScheduleId
                AND erl.ReminderDate = :todayDate2
            )
        ORDER BY cv.UserId, cv.IntakeTime
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':todayDate'  => $todayDate,
        ':todayDate2' => $todayDate,
        ':todayDay'   => '%' . $todayDay . '%'
    ]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    writeLog("Rows fetched: " . count($rows));

    if (!$rows) {
        echo "No reminders";
        exit;
    }

    $groupedReminders = [];

    foreach ($rows as $row) {
        $groupKey = $row['UserId'] . '_' . date('H:i', strtotime($row['IntakeTime']));

        if (!isset($groupedReminders[$groupKey])) {
            $groupedReminders[$groupKey] = [
                'UserId'     => $row['UserId'],
                'Email'      => $row['Email'],
                'UserName'   => $row['UserName'],
                'IntakeTime' => $row['IntakeTime'],
                'Vitamins'   => []
            ];
        }

        $groupedReminders[$groupKey]['Vitamins'][] = $row;
    }

    $logStmt = $pdo->prepare("
        INSERT INTO emailreminderlog (UserId, ScheduleId, ReminderDate, ReminderTime)
        VALUES (?, ?, ?, ?)
    ");

    foreach ($groupedReminders as $group) {

        if (sendProfessionalEmail($group, $mailConfig)) {

            foreach ($group['Vitamins'] as $v) {
                $logStmt->execute([
                    $v['UserId'],
                    $v['ScheduleId'],
                    $todayDate,
                    $v['IntakeTime']
                ]);
            }

            echo "Sent to: " . $group['Email'] . "<br>";
        }
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

function sendProfessionalEmail($group, $mailConfig)
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = $mailConfig['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $mailConfig['username'];
        $mail->Password   = $mailConfig['password'];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = $mailConfig['port'];
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom($mailConfig['from_email'], $mailConfig['from_name']);
        $mail->addAddress($group['Email'], $group['UserName']);

        $mail->isHTML(true);
        $mail->Subject = 'VitaCare Reminder';

        $body = "Reminder to take vitamins:<br>";

        foreach ($group['Vitamins'] as $v) {
            $body .= $v['VitaminName'] . " - Pills: " . $v['NumOfPills'] . "<br>";
        }

        $mail->Body = $body;

        return $mail->send();

    } catch (Exception $e) {
        return false;
    }
}