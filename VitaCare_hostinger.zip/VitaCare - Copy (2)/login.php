<?php
session_start();
require_once 'db_connection.php'; 
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $pass = $_POST['password'];

    try {
        // 1. Fetch the user by email
        $stmt = $pdo->prepare("SELECT * FROM user WHERE Email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // 2. Verify password against the stored hash
        if ($user && password_verify($pass, $user['Password'])) {
            
            // 3. Set Session variables for security and personalization
            $_SESSION['user_id'] = $user['UserId'];
            $_SESSION['username'] = $user['UserName'];
            $_SESSION['user_type'] = $user['UserType'];

            // 4. Role-based redirection
            if ($user['UserType'] === 'admin') {
                header("Location: admin_dashboard.php"); 
            } else {
                header("Location: customer-dashboard.php"); 
            }
            exit();
            
        } else {
            $message = "Invalid email or password.";
        }
    } catch(PDOException $e) {
        $message = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>VitaCare - Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <main class="main">
    <section class="card">
      <h1>VitaCare</h1>

      <div class="logo">
        <img src="image/logo.png" alt="VitaCare logo">
      </div>

      <div id="modalMessage" class="message-box"></div>
        <input type="hidden" id="editIndex">

      <form class="login-form" action="login.php" method="POST">
        <fieldset>
          <legend>Login</legend>

          <label for="email">Email Address:</label>
          <input id="email" name="email" type="email" placeholder="Type your email" required>

          <label for="password">Password:</label>
          <input id="password" name="password" type="password" placeholder="Type your password" required>
          <p id="pw-error" style="color: #d93025; font-size: 0.85rem; margin-top: 5px; display: none;"></p>
          
          <button class="btn btn-wide" type="submit">Login</button>

          <button class="btn btn-wide" type="button" onclick="window.location.href='index.php'">
            Back
          </button>

        </fieldset>
      </form>

    </section>
  </main>

  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-left">
       <strong>Contact Us:</strong>
      </div>
      <div class="footer-mid">
        <span class="contact-item">
          <img class="icon" src="image/email.png" alt="Email icon" />
          <a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
        </span>
        <span class="contact-item">
           <img class="icon" src="image/phone.png" alt="Phone icon" />
          <a class="footer-link" href="tel:+966556678127">+966 556678127</a>
        </span>
      </div>
      <div class="footer-bottom">
        &copy; 2026 <a class="footer-link" href="index.html">VitaCare</a>. All rights reserved.
      </div>
    </div>
  </footer>

  <script>
  const loginForm = document.querySelector(".login-form");
  const passwordInput = document.getElementById("password");


  function showModalMessage(text, type = "error") {
    const box = document.getElementById("modalMessage");
    if (!box) return;
    
    box.innerText = text;
    box.className = "message-box message-" + type; // Adds 'message-error'
    box.style.display = "block";
  }

  
  <?php if ($message): ?>
    showModalMessage("<?php echo addslashes($message); ?>", "error");
  <?php endif; ?>

 
  loginForm.addEventListener("submit", function (e) {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/;
    
    if (!passwordRegex.test(passwordInput.value)) {
      e.preventDefault(); 
      
     
      showModalMessage("Password must include uppercase, lowercase, a number, and a special character.", "error");
      
  
      passwordInput.focus();
    }
  });
</script>
</body>
</html>