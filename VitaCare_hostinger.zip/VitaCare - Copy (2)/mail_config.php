<?php
return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'vitacare.notifications@gmail.com',
    'password' => 'kajwchukapwhveiu',
    'from_email' => 'vitacare.notifications@gmail.com',
    'from_name' => 'VitaCare'
]; 

 