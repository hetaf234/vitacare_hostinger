<?php
session_start();
require_once 'db_connection.php';

/* =========================
   DELETE
========================= */
if (isset($_POST['delete_index'])) {
    $vitaminId = (int) $_POST['delete_index'];

    $stmt = $pdo->prepare("SELECT VitaminName FROM VitaminCatalog WHERE VitaminId = ?");
    $stmt->execute([$vitaminId]);
    $vitamin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($vitamin) {
        $name = $vitamin['VitaminName'];

        $deleteStmt = $pdo->prepare("DELETE FROM VitaminCatalog WHERE VitaminId = ?");
        $deleteStmt->execute([$vitaminId]);

        header("Location: admin_dashboard.php?success=deleted&name=" . urlencode($name));
        exit();
    }
}

/* =========================
   FETCH ALL VITAMINS
========================= */
$search = trim($_GET['search'] ?? '');

if ($search !== '') {
    $stmt = $pdo->prepare("
        SELECT VitaminId, VitaminName, VitaminDosage
        FROM VitaminCatalog
        WHERE VitaminName LIKE ? OR VitaminDosage LIKE ?
        ORDER BY VitaminName ASC, VitaminDosage ASC
    ");
    $like = "%" . $search . "%";
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->prepare("
        SELECT VitaminId, VitaminName, VitaminDosage
        FROM VitaminCatalog
        ORDER BY VitaminName ASC, VitaminDosage ASC
    ");
    $stmt->execute();
}

$vitamins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin - VitaCare</title>
<link rel="stylesheet" href="admin_dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>

<div class="navbar">
    <div class="logo">
        <img src="image/logo.PNG" alt="VitaCare Logo">
    </div>
    <div class="nav-title">Admin Dashboard</div>
    <a href="#" class="user-menu">
        <img src="image/icon.png" alt="User" class="user-img">
        <span>Admin</span>
    </a>
</div>

<?php if (isset($_GET['success']) && $_GET['success'] === 'deleted'): ?>
    <div class="success-banner" id="successBanner">
        <?php echo htmlspecialchars($_GET['name']); ?> has been deleted successfully.
    </div>
<?php elseif (isset($_GET['success']) && $_GET['success'] === 'added'): ?>
    <div class="success-banner" id="successBanner">
        <?php echo htmlspecialchars($_GET['name']); ?> has been added successfully.
    </div>
<?php elseif (isset($_GET['success']) && $_GET['success'] === 'updated'): ?>
    <div class="success-banner" id="successBanner">
        <?php echo htmlspecialchars($_GET['name']); ?> has been updated successfully.
    </div>
<?php endif; ?>

<div class="admin-container">
    <div class="add-btn-container">
        <a href="add-vitamin.php" class="add-btn">
            <i class="fa-solid fa-plus"></i> Add Vitamin
        </a>
    </div>

    <!-- SEARCH BAR -->
    <div class="search-bar-container">
        <form method="GET">
            <input
                type="text"
                name="search"
                class="search-input"
                placeholder="Search vitamin..."
                value="<?php echo htmlspecialchars($search); ?>"
            >
        </form>
    </div>

    <div class="admin-box">
        <?php if (empty($vitamins)): ?>
            <p style="text-align:center; color:#888;">
                <?php echo ($search !== '') ? 'No matching vitamins found.' : 'No vitamins added yet.'; ?>
            </p>
        <?php else: ?>
            <?php foreach ($vitamins as $v): ?>
                <div class="vitamin-row">
                    <span><?php echo htmlspecialchars($v['VitaminName']); ?> - <?php echo htmlspecialchars($v['VitaminDosage']); ?></span>
                    <div class="actions">
                        <a href="edit-vitamin.php?index=<?php echo (int)$v['VitaminId']; ?>" class="icon-btn edit">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <button type="button" class="icon-btn delete open-delete-modal" data-index="<?php echo (int)$v['VitaminId']; ?>" data-name="<?php echo htmlspecialchars($v['VitaminName']); ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div style="margin-top: 40px; text-align: left;">
        <button id="logoutBtn" class="logout-btn">
            <i class="fa-solid fa-sign-out-alt"></i> Log Out
        </button>
        <div id="messageBox" class="message-box" style="margin-top: 15px;"></div>
    </div>
</div>

<footer class="footer">
    <div class="footer-line"></div>
    <div class="footer-inner">
        <p class="contact-title">Contact Us:</p>
        <div class="contact-row">
            <span class="contact-item">
                <img src="image/email.png" alt="Email" class="icon">
                <a href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
            </span>
            <span class="contact-item">
                <img src="image/phone.png" alt="Phone" class="icon">
                <a href="tel:+966556678127">+966 556678127</a>
            </span>
        </div>
        <p class="copyright">
            &copy; 2026 <a href="index.php">VitaCare</a>. All rights reserved.
        </p>
    </div>
</footer>

<!-- DELETE MODAL -->
<div id="deleteModal" class="delete-modal">
    <div class="delete-modal-box">
        <h2>Delete Vitamin</h2>
        <p id="deleteVitaminName">Are you sure you want to delete this vitamin?</p>
        <div class="delete-modal-actions">
            <button type="button" id="confirmDeleteBtn" class="modal-delete-btn" style="width:50%">Delete</button>
            <button type="button" id="cancelDeleteBtn" class="modal-cancel-btn" style="width:50%">Cancel</button>
        </div>
    </div>
</div>

<!-- LOGOUT MODAL -->
<div id="logoutModal" class="delete-modal">
    <div class="delete-modal-box">
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out of your account?</p>
        <div class="delete-modal-actions">
            <button type="button" id="confirmLogoutBtn" class="modal-delete-btn" style="width:50%">Log Out</button>
            <button type="button" id="cancelLogoutBtn" class="modal-cancel-btn" style="width:50%">Cancel</button>
        </div>
    </div>
</div>

<script>
// ==================== LOGOUT FUNCTIONALITY ====================
const logoutBtn = document.getElementById("logoutBtn");
const messageBox = document.getElementById("messageBox");
const logoutModal = document.getElementById("logoutModal");
const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
const cancelLogoutBtn = document.getElementById("cancelLogoutBtn");

function performLogout() {
    if (logoutModal) {
        logoutModal.classList.remove("show");
    }

    if (messageBox) {
        messageBox.textContent = "Logout successful. Redirecting...";
        messageBox.className = "message-box message-success";
        messageBox.style.display = "block";
    }

    setTimeout(function() {
        window.location.href = "index.php";
    }, 1200);
}

if (logoutBtn) {
    logoutBtn.addEventListener("click", function(e) {
        e.preventDefault();
        if (logoutModal) {
            logoutModal.classList.add("show");
        }
    });
}

if (confirmLogoutBtn) {
    confirmLogoutBtn.addEventListener("click", function() {
        performLogout();
    });
}

if (cancelLogoutBtn) {
    cancelLogoutBtn.addEventListener("click", function() {
        if (logoutModal) {
            logoutModal.classList.remove("show");
        }
    });
}

// ==================== DELETE VITAMIN FUNCTIONALITY ====================
let deleteIndex = null;
const deleteModal = document.getElementById("deleteModal");
const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
const deleteVitaminNameSpan = document.getElementById("deleteVitaminName");

document.querySelectorAll(".open-delete-modal").forEach(btn => {
    btn.addEventListener("click", function() {
        deleteIndex = this.getAttribute("data-index");
        const vitaminName = this.getAttribute("data-name");
        deleteVitaminNameSpan.innerHTML = `Are you sure you want to delete "<strong>${vitaminName}</strong>"?`;
        deleteModal.classList.add("show");
    });
});

if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener("click", function() {
        if (deleteIndex !== null) {
            const form = document.createElement("form");
            form.method = "POST";
            form.action = "";
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "delete_index";
            input.value = deleteIndex;
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    });
}

if (cancelDeleteBtn) {
    cancelDeleteBtn.addEventListener("click", function() {
        deleteModal.classList.remove("show");
        deleteIndex = null;
    });
}

window.addEventListener("click", function(e) {
    if (e.target === deleteModal) {
        deleteModal.classList.remove("show");
        deleteIndex = null;
    }
    if (e.target === logoutModal) {
        logoutModal.classList.remove("show");
    }
});

const banner = document.getElementById("successBanner");
if (banner) {
    setTimeout(() => {
        banner.style.display = "none";
    }, 3000);
}

if (messageBox) {
    messageBox.style.display = "none";
}
</script>

</body>
</html>